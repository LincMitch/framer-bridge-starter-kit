import * as React from "react"
import * as System from "../../design-system"
import { ControlType, PropertyControls } from "framer"

type Props = System.TopAppBarFixedAdjustProps & {
  title: string
}

export class TopAppBarFixedAdjust extends React.Component<Props> {
  render() {
    return <System.TopAppBarFixedAdjust {...this.props} ></System.TopAppBarFixedAdjust>
  }

  static defaultProps: Props = {
    title: "Title",
  }

  static propertyControls: PropertyControls<Props> = {
    title: { type: ControlType.String, title: "Title" },
  }
}
