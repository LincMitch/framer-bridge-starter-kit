import * as React from "react"
import * as System from "../../design-system"
import { ControlType, PropertyControls } from "framer"

type Props = System.ButtonProps & {
}

export class Button extends React.Component<Props> {
  render() {
    return <System.Button {...this.props} />
  }

  static defaultProps: Props = {
  }

  static propertyControls: PropertyControls<Props> = {
    // children: { type: ControlType.String, title: "Children" },
    stickyColumns: { type: ControlType.String, title: "Sticky Columns" },
    stickyRows: { type: ControlType.String, title: "Sticky Rows" },
  }
}
