import * as React from "react"
import * as System from "../../design-system"
import { ControlType, PropertyControls, Scroll } from "framer"
import { cloneFrameless } from "../../design-system-v2.framerfx/node_modules/@framer/lintonye.learnreactdesign-ds/code/tools/framerx-utils";

type Props = System.CardActionsProps & {
  cardPrimaryActionAndButtons: string[];
  externalCardPrimaryActionAndButtons: React.ReactNode;
  activeCardPrimaryActionAndButtonsIndex: number;
}

export class CardActions extends React.Component<Props> {
  render() {
    const { cardPrimaryActionAndButtons, externalCardPrimaryActionAndButtons, ...rest } = this.props;

    let topAppBarRowElements;
    topAppBarRowElements = cloneFrameless(externalCardPrimaryActionAndButtons); 
    return <System.CardActions {...this.props} >{topAppBarRowElements}</System.CardActions>
  }

  static defaultProps: Props = {
    activeCardPrimaryActionAndButtonsIndex: 0
  }

  static propertyControls: PropertyControls<Props> = {

    externalCardPrimaryActionAndButtons: {
      type: ControlType.ComponentInstance,
      title: "CardPrimaryActionAndButtons"
    },
    activeCardPrimaryActionAndButtonsIndex: {
      type: ControlType.Number,
      title: "Index",
      min: 0
    }
  }
}
