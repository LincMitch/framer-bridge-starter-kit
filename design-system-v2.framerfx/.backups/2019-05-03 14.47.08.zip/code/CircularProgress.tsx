import * as React from "react"
import * as System from "../../design-system"
import { ControlType, PropertyControls } from "framer"

type Props = System.CircularProgressProps & {
  width: number
  height: number
}

export class CircularProgress extends React.Component<Props> {
  render() {
    return <System.CircularProgress {...this.props} />
  }

  static defaultProps: Props = {
    width: 150,
    height: 48,
  }

  static propertyControls: PropertyControls<Props> = {
    buffer: { type: ControlType.Number, title: "buffer" },
    closed: { type: ControlType.Boolean, title: "closed" },
    progress: { type: ControlType.Number, title: "progress" },
    reversed: { type: ControlType.Boolean, title: "reversed" },
  }
}
