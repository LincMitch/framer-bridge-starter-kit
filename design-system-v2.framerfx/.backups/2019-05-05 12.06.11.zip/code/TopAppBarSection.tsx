import * as React from "react"
import * as System from "../../design-system"
import { ControlType, PropertyControls, Scroll } from "framer"
import { cloneFrameless } from "../../design-system-v2.framerfx/node_modules/@framer/lintonye.learnreactdesign-ds/code/tools/framerx-utils";

type Props = System.TopAppBarSectionProps & {
  TopAppBarSection: string[];
  externalTopAppBarSection: React.ReactNode;
  activeTopAppBarSectionIndex: number;
}

export class TopAppBarSection extends React.Component<Props> {
  render() {
    const { TopAppBarSection, externalTopAppBarSection, ...rest } = this.props;

    let toolbarTitleElements;
    toolbarTitleElements = cloneFrameless(externalTopAppBarSection); 
    return <System.TopAppBarSection {...this.props} ></System.TopAppBarSection>
  }

  static defaultProps: Props = {
  }

  static propertyControls: PropertyControls<Props> = {
    alignEnd: { type: ControlType.Boolean, title: "Align End" },
    alignStart: { type: ControlType.Boolean, title: "Align Start" }

    externalTopAppBarSection: {
      type: ControlType.ComponentInstance,
      title: "TopAppBarSection"
    },

  }
}
