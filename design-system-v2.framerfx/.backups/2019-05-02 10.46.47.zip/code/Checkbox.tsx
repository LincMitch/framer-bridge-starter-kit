import * as React from "react"
import * as System from "../../design-system"
import { ControlType, PropertyControls } from "framer"

type Props = System.IconProps & {
}

export class Checkbox extends React.Component<Props> {
  render() {
    return <System.Checkbox {...this.props} />
  }

  static defaultProps: Props = {

  }

  static propertyControls: PropertyControls<Props> = {
    use: { type: ControlType.String, title: "Use" },
    text: { type: ControlType.String, title: "Text" }
    checked?: string;
    disabled?: boolean;
    id?: boolean;
    indeterminate?: string;
    // inputRef
    label?: string;
    ripple?: boolean;
    rootProps?: object;
    value?: string;
  }
}
