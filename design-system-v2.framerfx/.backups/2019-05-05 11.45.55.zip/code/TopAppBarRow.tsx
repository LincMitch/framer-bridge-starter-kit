import * as React from "react"
import * as System from "../../design-system"
import { ControlType, PropertyControls, Scroll } from "framer"

type Props = System.TopAppBarRowProps & {
  topAppBarRows: string[];
  externalTopAppBarRows: React.ReactNode;
  activeTopAppBarRowsIndex: number;

}

export class TopAppBarRow extends React.Component<Props> {
  render() {
    const { topAppBarRows, externalTopAppBarRows, ...rest } = this.props;

    let topAppBarRowElements;
    topAppBarRowElements = cloneFrameless(externalTopAppBarRows); 
    return <System.TopAppBarRow {...this.props} ></System.TopAppBarRow>
  }

  static defaultProps: Props = {

  }

  static propertyControls: PropertyControls<Props> = {
    externalTopAppBarRows: {
      type: ControlType.ComponentInstance,
      title: "TopAppBarRows"
    },
  }
  
}
