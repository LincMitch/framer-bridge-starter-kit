import * as React from "react"
export class Chip extends React.Component {
  render() {
    return <div>asd</div>
  }
}
