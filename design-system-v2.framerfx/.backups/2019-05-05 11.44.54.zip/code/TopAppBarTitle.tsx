import * as React from "react"
import * as System from "../../design-system"
import { ControlType, PropertyControls } from "framer"

type Props = System.TopAppBarTitleProps & {
  title: string;

  topAppBarTitles: string[];
  externalTopAppBarTitles: React.ReactNode;
  activeTopAppBarTitlesIndex: number;
}

export class TopAppBarTitle extends React.Component<Props> {
  render() {
    const { topAppBarTitles, externalTopAppBarTitles, ...rest } = this.props;

    let topAppBarTitleElements;
    topAppBarTitleElements = cloneFrameless(externalTopAppBarTitles); 
    return <System.TopAppBarTitle {...this.props} ></System.TopAppBarTitle>
  }

  static defaultProps: Props = {
    title: "Title",
  }

  static propertyControls: PropertyControls<Props> = {
    title: { type: ControlType.String, title: "Title" },

    externalTopAppBarTitles: {
      type: ControlType.ComponentInstance,
      title: "TopAppBarTitles"
    },
  }
}
