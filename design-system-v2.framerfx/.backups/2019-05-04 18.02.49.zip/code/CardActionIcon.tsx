import * as React from "react"
import * as System from "../../design-system"
import { ControlType, PropertyControls } from "framer"

type Props = System.CardActionIconProps & {

}

export class CardActionIcon extends React.Component<Props> {
  render() {
    return <System.CardActionIcon {...this.props} />
  }

  static defaultProps: Props = {

  }

  static propertyControls: PropertyControls<Props> = {

  }
}
