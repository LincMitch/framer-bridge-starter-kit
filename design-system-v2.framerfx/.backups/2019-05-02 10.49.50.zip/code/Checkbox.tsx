import * as React from "react"
import * as System from "../../design-system"
import { ControlType, PropertyControls } from "framer"

type Props = System.CheckboxProps & {
}

export class Checkbox extends React.Component<Props> {
  render() {
    return <System.Checkbox {...this.props} />
  }

  static defaultProps: Props = {

  }

  static propertyControls: PropertyControls<Props> = {
    checked={ type: ControlType.String, title: "Checked" },
    disabled={ type: ControlType.Boolean, title: "Disabled" },
    id={ type: ControlType.Boolean, title: "ID" },
    indeterminate={ type: ControlType.String, title: "Indeterminate" },
    // inputRef
    label={ type: ControlType.String, title: "Label" },
    ripple={ type: ControlType.Boolean, title: "Ripple" },
    // rootProps?: object;
    value={ type: ControlType.String, title: "Value" },
  }
}
