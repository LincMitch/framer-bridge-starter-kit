import * as React from "react"
import * as System from "../../design-system"
import { ControlType, PropertyControls } from "framer"

type Props = System.ToolbarProps & {
  toolbarRows: string[];
  externalToolbarRows: React.ReactNode;
  activeToolbarRowsIndex: number;
}

export class Toolbar extends React.Component<Props> {
  render() {
    return <System.Toolbar {...this.props} />
  }

  static defaultProps: Props = {
    activeToolbarRowsIndex: 0
  }

  static propertyControls: PropertyControls<Props> = {
    fixed: { type: ControlType.Boolean, title: "Fixed" },
    fixedLastrowOnly: { type: ControlType.Boolean, title: "Fixed LastrowOnly" },
    flexible: { type: ControlType.Boolean, title: "Flexible" },
    flexibleDefaultBehavior: { type: ControlType.String, title: "FlexibleDefaultBehavior" },
    waterfall: { type: ControlType.Boolean, title: "Waterfall" },   

    externalToolbarRows: {
      type: ControlType.ComponentInstance,
      title: "ToolbarRows"
    },
    activeToolbarRowsIndex: {
      type: ControlType.Number,
      title: "Index",
      min: 0
    }
  }
}
