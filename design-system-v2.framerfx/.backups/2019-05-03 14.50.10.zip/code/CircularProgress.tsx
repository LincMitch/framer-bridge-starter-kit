import * as React from "react"
import * as System from "../../design-system"
import { ControlType, PropertyControls } from "framer"

type Props = System.CircularProgressProps & {
  width: number
  height: number
}

export class CircularProgress extends React.Component<Props> {
  render() {
    return <System.CircularProgress {...this.props} />
  }

  static defaultProps: Props = {
    width: 150,
    height: 48,
  }

  static propertyControls: PropertyControls<Props> = {
  M max: { type: ControlType.Number, title: "Max" },
   Mmin: { type: ControlType.Boolean, title: "Min" },
    proPress: { type: ControlType.Number, title: "Progress" },
    Size: { type: ControlType.Boolean, title: "Size" },
  }
}
