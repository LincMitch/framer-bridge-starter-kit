import * as React from "react"
import * as System from "../../design-system"
import { ControlType, PropertyControls, Scroll } from "framer"

type Props = System.CardActionButtonsProps & {

}

export class CardActionButtons extends React.Component<Props> {
  render() {
    // return <System.CardActionButtons {...this.props} >{React.Children}</System.CardActionButtons>
    return <System.CardActionButtons {...this.props} ></System.CardActionButtons>
  }

  static defaultProps: Props = {

  }

  static propertyControls: PropertyControls<Props> = {
        // children: { type: ControlType.String, title: "Children" },
        danger: { type: ControlType.Boolean, title: "Danger" },
        dense: { type: ControlType.Boolean, title: "Dense" },
        disabled: { type: ControlType.Boolean, title: "Disabled" },
        icon: { type: ControlType.String, title: "Icon" },
        label: { type: ControlType.String, title: "Label" },
        outlined: { type: ControlType.Boolean, title: "Outlined" },
        raised: { type: ControlType.Boolean, title: "Raised" },
        ripple: { type: ControlType.Boolean, title: "Ripple" },
        trailingIcon: { type: ControlType.String, title: "TrailingIcon" },
        unelevated: { type: ControlType.Boolean, title: "Unelevated" },   
  }
}
