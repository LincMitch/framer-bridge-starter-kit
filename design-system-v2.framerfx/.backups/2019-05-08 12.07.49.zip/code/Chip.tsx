import * as React from "react"
import * as System from "../../design-system"
import { ControlType, PropertyControls } from "framer"

type Props = System.ChipProps & {
}

export class Chip extends React.Component<Props> {
  render() {
    return <System.Chip {...this.props} />
  }

  static defaultProps: Props = {
    label: "label",
  }

  static propertyControls: PropertyControls<Props, any> = {
    checkmark:	{ type: ControlType.Boolean, title: "Checkmark" },
    children:	{ type: ControlType.Boolean, title: "children" },
    icon:		{ type: ControlType.String, title: "Icon" },
    id:		{ type: ControlType.String, title: "Id" },
    label: { type: ControlType.String, title: "Label" },
    onInteraction: { type: ControlType.String, title: "Label" },
    onRemove: { type: ControlType.String, title: "onRemove" },
    onTrailingIconInteraction: { type: ControlType.String, title: "onTrailingIconInteraction" },
    selected:	{ type: ControlType.Boolean, title: "Selected" },	
    trailingIcon:		{ type: ControlType.String, title: "TrailingIcon" },
  }
}
