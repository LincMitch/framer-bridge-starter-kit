import * as React from "react"
import * as System from "../../design-system"
import { ControlType, PropertyControls } from "framer"

type Props = System.ButtonProps & {
  width: number
  height: number
}

export class Button extends React.Component<Props> {
  render() {
    return <System.Button {...this.props} />
  }

  static defaultProps: Props = {
    width: 150,
    height: 48,
    disabled: false,
    label: "Button"
  }

  static propertyControls: PropertyControls<Props> = {
    // children: { type: ControlType.String, title: "Children" },
    dense: { type: ControlType.String, title: "Dense" },
    disabled: { type: ControlType.String, title: "Disabled" },
    selected: { type: ControlType.String, title: "Selected" },
    // icon: { type: ControlType.String, title: "Icon" },
    label: { type: ControlType.String, title: "Label" },
    outlined: { type: ControlType.String, title: "Outlined" },
    raised: { type: ControlType.String, title: "Raised" },
    ripple: { type: ControlType.String, title: "Ripple" },
    trailingIcon: { type: ControlType.String, title: "TrailingIcon" },
    unelevated: { type: ControlType.String, title: "Unelevated" },   
  }
}
