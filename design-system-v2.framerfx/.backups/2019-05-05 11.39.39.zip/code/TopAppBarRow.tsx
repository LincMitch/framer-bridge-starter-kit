import * as React from "react"
import * as System from "../../design-system"
import { ControlType, PropertyControls, Scroll } from "framer"

type Props = System.TopAppBarRowProps & {
  toolbarTitles: string[];
  externalToolbarTitles: React.ReactNode;
  activeToolbarTitlesIndex: number;

}

export class TopAppBarRow extends React.Component<Props> {
  render() {
    const { toolbarTitles, externalToolbarTitles, ...rest } = this.props;

    let toolbarTitleElements;
    toolbarTitleElements = cloneFrameless(externalToolbarTitles); 
    return <System.TopAppBarRow {...this.props} ></System.TopAppBarRow>
  }

  static defaultProps: Props = {

  }

  static propertyControls: PropertyControls<Props> = {
    externalToolbarTitles: {
      type: ControlType.ComponentInstance,
      title: "ToolbarTitles"
    },
  }
  
}
