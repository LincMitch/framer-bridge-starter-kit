import * as React from "react"
import * as System from "../../design-system"
import { ControlType, PropertyControls } from "framer"
import { cloneFrameless } from "../../design-system-v2.framerfx/node_modules/@framer/lintonye.learnreactdesign-ds/code/tools/framerx-utils";

type Props = System.CardActionIconProps & {
  cardActionIcon: string[];
  externalCardActionIcon: React.ReactNode;
  activeCardActionIconIndex: number;
}

export class CardActionIcon extends React.Component<Props> {
  render() {
    const { cardActionIcon, externalCardActionIcon, ...rest } = this.props;

    let topAppBarRowElements;
    topAppBarRowElements = cloneFrameless(externalCardActionIcon); 
    return <System.CardActionIcon {...this.props} >{topAppBarRowElements}</System.CardActionIcon>
  }

  static defaultProps: Props = {
    activeCardActionIconIndex: 0
  }

  static propertyControls: PropertyControls<Props> = {
    checked: { type: ControlType.Boolean, title: "Checked" },
    disabled: { type: ControlType.Boolean, title: "Disabled" },
    icon: { type: ControlType.String, title: "Icon" },
    // icon: { type: ControlType.String, title: "Icon" },
    // onChange: { type: ControlType.String, title: "On Change" },
    // onIcon: { type: ControlType.Boolean, title: "On Icon" },
    ripple: { type: ControlType.Boolean, title: "Rripple" },

    externalCardActionIcon: {
      type: ControlType.ComponentInstance,
      title: "CardActionIcon"
    },
    activeCardActionIconIndex: {
      type: ControlType.Number,
      title: "Index",
      min: 0
    }
  }
}
