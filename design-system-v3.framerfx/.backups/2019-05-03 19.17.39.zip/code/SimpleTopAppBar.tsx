import * as React from "react"
import * as System from "../../design-system"
import { ControlType, PropertyControls } from "framer"

type Props = System.SimpleTopAppBarProps & {
  actionItems: object
  dense: boolean
  endContent: React.ReactNode
  fixed: boolean
  navigationIcon: boolean
  // onNav: boolean
  prominent: boolean
  // scrollTarget: Element
  short: boolean
  shortCollapsed: boolean
  startContent: React.ReactNode
  title: string

export class SimpleTopAppBar extends React.Component<Props> {
  render() {
    return <System.SimpleTopAppBar {...this.props} ></System.SimpleTopAppBar>
  }

  static defaultProps: Props = {

  }

  static propertyControls: PropertyControls<Props> = {
    dense: { type: ControlType.Boolean, title: "Dense" },
    denseProminent: { type: ControlType.Boolean, title: "Dense Prominent" },
    prominent: { type: ControlType.Boolean, title: "Prominent" },
    short: { type: ControlType.Boolean, title: "Short" },
  }
}
