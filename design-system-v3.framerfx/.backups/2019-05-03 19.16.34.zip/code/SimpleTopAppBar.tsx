import * as React from "react"
import * as System from "../../design-system"
import { ControlType, PropertyControls } from "framer"

type Props = System.SimpleTopAppBarProps & {
  dense: boolean
  denseProminent: boolean
  prominent: boolean
  short: boolean
}

export class SimpleTopAppBar extends React.Component<Props> {
  render() {
    return <System.SimpleTopAppBar {...this.props} ></System.SimpleTopAppBar>
  }

  static defaultProps: Props = {

  }

  static propertyControls: PropertyControls<Props> = {
    dense: { type: ControlType.Boolean, title: "Dense" },
    denseProminent: { type: ControlType.Boolean, title: "Dense Prominent" },
    prominent: { type: ControlType.Boolean, title: "Prominent" },
    short: { type: ControlType.Boolean, title: "Short" },
  }
}
